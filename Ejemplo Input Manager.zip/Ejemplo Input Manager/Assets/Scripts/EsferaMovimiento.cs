using UnityEngine;


public class EsferaMovimiento : MonoBehaviour
{
    [SerializeField] float velocidad;



    void Update()
    {
        // "Input.GetAxis("Mi Axis Horizontal");" se ocupa de obtener el axis
        // que revisamos en el Input Manager.
        // Ese axis, en c�digo, se procesa de la siguiente forma:
        //
        // Cuando lo llamamos, nosotros vamos a obtener simplemente un float (un n�mero con coma).
        // Ese n�mero con coma va a variar seg�n la tecla que estemos presionando:
        // 
        // * Si estamos presionando el valor positivo, entonces ese float va a valer "1".
        // * Si estamos presionando el valor negativo, entonces ese float va a valer "-1".
        // * Si no estamos presionando ni el negativo ni el positivo, entonces ese float vale 0.
        //
        // Este valor se va a actualizar en tiempo de ejecuci�n.
        // Este valor va a depender de lo que el usuario presione. Nada m�s de eso.
        //
        // Por otro lado, siempre guardamos ese valor en una variable para que el c�digo
        // sea m�s legible.
        //
        // Nosotros modificamos nuestro axis en el Input Manager, cambi�ndole el nombre a
        // "Mi Axis Horizontal". Por otro lado, las teclas que indicamos para los
        // valores negativos y positivos son "a" y "d".
        float inputHorizontalPropio = Input.GetAxis("Mi Axis Horizontal");

        transform.position += transform.right * inputHorizontalPropio * velocidad * Time.deltaTime;
    }
}
